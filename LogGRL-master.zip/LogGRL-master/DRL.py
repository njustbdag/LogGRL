import random
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from collections import deque
import itertools
import pandas as pd
import csv
from tqdm import tqdm
import math
import copy

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Using device:", device)

class ReplayBuffer:

    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = deque(maxlen=capacity)

    def push(self, state, action, reward, next_state, done):
        self.buffer.append((state, action, reward, next_state, done))

    def sample(self, batch_size):
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        states = torch.LongTensor(states).to(device)  # [batch_size, window_size]
        actions = torch.LongTensor(actions).to(device)  # [batch_size]
        rewards = torch.FloatTensor(rewards).to(device)  # [batch_size]
        # Replace None next_states with zeros
        next_states = torch.LongTensor(
            [ns if ns is not None else [0] * states.size(1) for ns in next_states]
        ).to(device)
        dones = torch.FloatTensor(dones).to(device)  # [batch_size]
        return states, actions, rewards, next_states, dones

    def __len__(self):
        return len(self.buffer)


class QNetwork(nn.Module):

    def __init__(self, node_count, embed_dim, window_size, hidden_dim):
        super(QNetwork, self).__init__()
        self.embed = nn.Embedding(node_count, embed_dim)
        with torch.no_grad():
            self.embed.weight[0] = torch.zeros(embed_dim)
        self.window_size = window_size
        self.embed_dim = embed_dim

        # Define possible node-pair actions within the window
        # self.action_pairs = list(itertools.combinations(range(window_size), 2))# window hop
        self.action_pairs = list(zip(range(window_size - 1), range(1, window_size)))# order
        self.action_count = len(self.action_pairs)

        # Fully connected layers for Q-value approximation
        input_dim = window_size * embed_dim
        self.fc1 = nn.Linear(input_dim, hidden_dim)
        self.fc2 = nn.Linear(hidden_dim, hidden_dim)
        self.out = nn.Linear(hidden_dim, self.action_count)
        self.relu = nn.ReLU()

    def forward(self, state):
        embed = self.embed(state)  # [batch_size, window_size, embed_dim]
        embed_flat = embed.view(embed.size(0), -1)  # [batch_size, window_size * embed_dim]
        x = self.relu(self.fc1(embed_flat))
        x = self.relu(self.fc2(x))
        q_values = self.out(x)  # [batch_size, action_count]
        return q_values

    def get_action_pairs(self):
        return self.action_pairs


def select_action(state, policy_net, epsilon, action_pairs):
    if random.random() < epsilon:
        return random.randrange(len(action_pairs))
    else:
        state_tensor = torch.LongTensor([state]).to(device)  # [1, window_size]
        with torch.no_grad():
            q_values = policy_net(state_tensor)  # [1, action_count]
        action = q_values.argmax(dim=1).item()
        return action


def train_ddqn(paths, node_count, window_size=3, embed_dim=64, hidden_dim=128,
               buffer_capacity=10000, batch_size=64, lr=1e-3, gamma=0.99,
               epsilon_start=1.0, epsilon_end=0.01, epsilon_decay=0.995,
               target_update_freq=10, num_epochs=10,zeta=1):

    # Initialize networks
    policy_net = QNetwork(node_count, embed_dim, window_size, hidden_dim).to(device)
    target_net = QNetwork(node_count, embed_dim, window_size, hidden_dim).to(device)
    target_net.load_state_dict(policy_net.state_dict())
    target_net.eval()

    optimizer = optim.Adam(policy_net.parameters(), lr=lr)
    replay_buffer = ReplayBuffer(buffer_capacity)

    epsilon = epsilon_start
    action_pairs = policy_net.get_action_pairs()

    # Training loop
    for epoch in range(num_epochs):
        random.shuffle(paths)
        for path, label in tqdm(paths, desc="Training DDQN"):
            path_len = len(path)
            if path_len < window_size:
                path+=[0]*(window_size-path_len)
                path_len=window_size
            # Slide window through path
            for idx in range(path_len - window_size + 1):
                state = path[idx: idx + window_size]
                if idx == path_len - window_size:
                    next_state = None
                    done = 1.0
                else:
                    next_state = path[idx + 1: idx + 1 + window_size]
                    done = 0.0

                action = select_action(state, policy_net, epsilon, action_pairs)
                reward = 1.0*zeta if label == 1 else -1.0

                replay_buffer.push(state, action, reward, next_state, done)

                # Sample and learn if enough data
                if len(replay_buffer) >= batch_size:
                    states_b, actions_b, rewards_b, next_states_b, dones_b = replay_buffer.sample(batch_size)

                    # Current Q-values for taken actions
                    q_values = policy_net(states_b)
                    current_q = q_values.gather(1, actions_b.unsqueeze(1)).squeeze(1)

                    # Double DQN target
                    with torch.no_grad():
                        next_q_policy = policy_net(next_states_b)
                        best_actions = next_q_policy.argmax(dim=1, keepdim=True)
                        next_q_target = target_net(next_states_b)
                        target_q = next_q_target.gather(1, best_actions).squeeze(1)
                        target_value = rewards_b + gamma * target_q * (1 - dones_b)

                    # Update network
                    loss = nn.MSELoss()(current_q, target_value)
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

            # Decay epsilon (after each episode)
            if epsilon > epsilon_end:
                epsilon *= epsilon_decay

        # Sync target network
        if (epoch + 1) % target_update_freq == 0:
            target_net.load_state_dict(policy_net.state_dict())
            print(f"Epoch {epoch + 1}: Target network synced.")

    return policy_net, target_net

def load_paths_from_csv(filepath, seq_sep=" ",window_size=5):
    df = pd.read_csv(filepath)
    paths = []
    for _, row in df.iterrows():
        sequence_str = row['Sequence']
        sequence = [int(x) for x in sequence_str.strip().split(seq_sep) if x]
        # # pad zero to path
        # sequence = [0] * (window_size - 1) + [int(x) for x in sequence_str.strip().split(seq_sep) if x]
        label = int(row['label'])
        paths.append((sequence, label))

    return paths


def generate_graph(policy_net, paths, window_size,path_weight_file):
    policy_net.eval()
    action_pairs = policy_net.get_action_pairs()
    edge_values = {}
    total_paths_weight=[]
    k = 1
    with torch.no_grad():
        for path, label in tqdm(paths, desc="writing weights"):
            path_len = len(path)
            path_weights=[]
            if path_len<window_size:
                pad_num = window_size - path_len
                state=path+[0]*pad_num
                state_tensor = torch.LongTensor([state]).to(device)
                q_values = policy_net(state_tensor).squeeze(0)
                for shot_idx in range(path_len-1):
                    (head, tail) = action_pairs[shot_idx]
                    u, v = state[head], state[tail]
                    weight_edge = 1 / (1 + math.exp(-k * q_values[action_idx].item()))
                    path_weights.append(round(weight_edge, 3))
                    edge = (u, v)
                    edge_values.setdefault(edge, []).append(q_values[action_idx].item())

            else:
                for idx in range(path_len - window_size + 1):
                    state = path[idx: idx + window_size]
                    state_tensor = torch.LongTensor([state]).to(device)
                    q_values = policy_net(state_tensor).squeeze(0)
                    if idx==0:
                        for action_idx, (i, j) in enumerate(action_pairs):
                            u, v = state[i], state[j]
                            weight_edge=1 / (1 + math.exp(-k * q_values[action_idx].item()))
                            path_weights.append(round(weight_edge,3))
                            edge = (u, v)
                            edge_values.setdefault(edge, []).append(q_values[action_idx].item())
                    else:
                        (head,tail) =action_pairs[-1]
                        u, v = state[head], state[tail]
                        weight_edge = 1 / (1 + math.exp(-k * q_values[action_idx].item()))
                        path_weights.append(round(weight_edge, 3))
                        edge = (u, v)
                        edge_values.setdefault(edge, []).append(q_values[action_idx].item())

            total_paths_weight.append(path_weights)

    # save .CSV file
    print('save',path_weight_file)
    with open(path_weight_file, 'w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(['path_weights'])
        for row in total_paths_weight:
            writer.writerow([' '.join(map(str, row))])

    edge_weights = {edge: float(np.mean(vals)) for edge, vals in edge_values.items()}

    # # min-max normalization
    # all_weights = list(edge_weights.values())
    # min_w = min(all_weights)
    # max_w = max(all_weights)
    # if max_w > min_w:
    #     for edge in edge_weights:
    #         edge_weights[edge] = (edge_weights[edge] - min_w) / (max_w - min_w)
    # else:
    #     for edge in edge_weights:
    #         edge_weights[edge] = 0.5

    # sigmoid normalization
    for edge in edge_weights:
        w = edge_weights[edge]
        edge_weights[edge] = 1 / (1 + math.exp(-k * w))

    return edge_weights


def save_graph_triples(edge_weights, filename='graph_triples.txt'):
    with open(filename, mode='w') as f:
        for (u, v), w in edge_weights.items():
            f.write(f"{u},{v},{w:.3f}\n")


if __name__ == "__main__":
    # Hyperparameters
    WINDOW_SIZE = 5
    EMBED_DIM = 32 # 32
    HIDDEN_DIM = 64 # 64
    BUFFER_CAPACITY = 5000 #5000
    BATCH_SIZE = 2048
    LR = 1e-3
    GAMMA = 0.99
    EPSILON_START = 1.0
    EPSILON_END = 0.01
    EPSILON_DECAY = 0.995
    TARGET_UPDATE_FREQ = 100
    NUM_EPOCHS = 5

    original_paths = load_paths_from_csv('FinalData/Thunderbird/train.csv', seq_sep=" ", window_size=WINDOW_SIZE)
    test_paths = load_paths_from_csv('FinalData/Thunderbird/test.csv', seq_sep=" ", window_size=WINDOW_SIZE)
    NODE_COUNT = 1206
    train_paths = copy.deepcopy(original_paths) # copy for training, Keep original_paths in their original order.


    policy_net, target_net = train_ddqn(train_paths, NODE_COUNT+1, window_size=WINDOW_SIZE,
                                         embed_dim=EMBED_DIM, hidden_dim=HIDDEN_DIM,
                                         buffer_capacity=BUFFER_CAPACITY, batch_size=BATCH_SIZE,
                                         lr=LR, gamma=GAMMA, epsilon_start=EPSILON_START,
                                         epsilon_end=EPSILON_END, epsilon_decay=EPSILON_DECAY,
                                         target_update_freq=TARGET_UPDATE_FREQ, num_epochs=NUM_EPOCHS,
                                         zeta=1)

    print('Training complete.')

    # Generate weighted path from the trained policy network
    graph_edge_weights = generate_graph(policy_net, original_paths, WINDOW_SIZE,path_weight_file='./FinalData/Thunderbird/train_weight.csv')
    test_edge_weights = generate_graph(policy_net, test_paths, WINDOW_SIZE,path_weight_file='./FinalData/Thunderbird/test_weight.csv')

    #save_graph_triples(graph_edge_weights, filename='train_graph.txt') # global edge weight
    #save_graph_triples(test_edge_weights, filename='test_graph.txt') # global edge weight


    # # Print top edges by weight
    # sorted_edges = sorted(graph_edge_weights.items(), key=lambda x: x[1], reverse=True)
    # print("Top edges by learned weight:")
    # for edge, weight in sorted_edges[:100]:
    #     print(f"Edge {edge} -> Weight {weight:.3f}")
