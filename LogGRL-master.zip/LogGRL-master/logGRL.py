import torch
import torch.nn as nn
import torch_geometric
from torch_geometric.nn import TransformerConv, global_mean_pool,GCNConv
import torch.optim as optim
from torch_geometric.data import Data, DataLoader
import pandas as pd
from sklearn.metrics import f1_score,accuracy_score, precision_score, recall_score
import numpy as np
from transformers import BertTokenizer, BertModel
from data_load import *
import torch.nn.functional as F
import math





def load_data_graph_transformer():
    print('Loading data for graph transformer...')

def get_train_sequences_data(train_path):
    train_data = pd.read_csv(train_path, engine='c')
    sequences = []
    sequences_str, labels = list(train_data['Sequence']), list(train_data['label'])
    for seq in sequences_str:
        array = seq.strip().split(' ')
        array = [int(i) - 1 for i in array]
        sequences.append(array)
    return sequences, labels

def get_path_weight(filename):
    train_data = pd.read_csv(filename, engine='c')
    path_weights = []
    path_weights_str= list(train_data['path_weights'])
    for seq in path_weights_str:
        if isinstance(seq, float) and math.isnan(seq):
            array = [1.0]
        else:
            array = seq.strip().split(' ')
            array = [float(i) for i in array]
        path_weights.append(array)
    normal_path_weights=normalize_path_weight(path_weights)
    return normal_path_weights

def normalize_path_weight(paths):
    normalized_path_weights = []
    for path in paths:
        max_val = max(path)
        normalized_data = [round(x / max_val, 3) for x in path]
        normalized_path_weights.append(normalized_data)
    return normalized_path_weights

def get_train_graph_data(sequences, labels, node_embedding, path_weight):
    graphs = []
    for label_index, seq in enumerate(sequences):
        graph_edges = [[], []]
        seq_dict = {}
        node_list = []
        edge_weights = path_weight[label_index]
        if len(seq) <= 1:
            edge_weights = []

        for i, node in enumerate(seq):
            if node not in seq_dict:
                seq_dict[node] = len(seq_dict)
                node_list.append(node)
            if i > 0:
                graph_edges[0].append(seq_dict[seq[i - 1]])
                graph_edges[1].append(seq_dict[node])

        node_features = node_embedding[node_list]
        graph_data = Data(
            x=node_features,
            edge_index=torch.tensor(graph_edges, dtype=torch.long),
            edge_attr=torch.tensor(edge_weights, dtype=torch.float).unsqueeze(1),
            y=torch.tensor([labels[label_index]])
        )
        graphs.append(graph_data)
    return graphs


def evaluate(model, sentence_embeddings,test_graphs, test_labels):
    print('start evaluation')
    model.eval()
    test_loader = DataLoader(test_graphs, batch_size=len(test_graphs))
    with torch.no_grad():
        for test_batch in test_loader:
            test_outputs=model(test_batch)
            pred=test_outputs.argmax(dim=1)
            all_preds = pred.tolist()
            all_labels = test_batch.y.tolist()
    # accuracy = accuracy_score(all_labels, all_preds)
    # print(accuracy)
    precision = precision_score(all_labels, all_preds, pos_label=1)
    recall = recall_score(all_labels, all_preds, pos_label=1)
    f1 = f1_score(all_labels, all_preds, pos_label=1)
    print(f"Precision for anomalies: {precision:.4f}")
    print(f"Recall for anomalies: {recall:.4f}")
    print(f"F1-Score for anomalies: {f1:.4f}")



class GraphTransformerEdge(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, out_channels, heads=1, dropout=0.0):
        super(GraphTransformerEdge, self).__init__()
        self.initial_linear = nn.Linear(768, in_channels)
        self.conv1 = TransformerConv(in_channels, hidden_channels, heads=heads,
                                     dropout=dropout, edge_dim=1)

        self.conv2 = TransformerConv(hidden_channels * heads, hidden_channels,
                                     heads=1, dropout=dropout, edge_dim=1)
        self.lin = nn.Linear(hidden_channels, out_channels)

    def forward(self, data):
        x, edge_index, edge_attr, batch = data.x, data.edge_index, data.edge_attr, data.batch
        x = self.initial_linear(x)
        x = self.conv1(x, edge_index, edge_attr)
        x = F.relu(x)
        x = F.dropout(x, p=self.conv1.dropout, training=self.training)
        x = self.conv2(x, edge_index, edge_attr)
        x = F.relu(x)
        x = F.dropout(x, p=self.conv2.dropout, training=self.training)
        x = global_mean_pool(x, batch)
        x = self.lin(x)
        return x

class GraphGCN(nn.Module):
    def __init__(self, node_feature_dim, hidden_dim, output_dim):
        super(GraphGCN, self).__init__()
        self.initial_linear = nn.Linear(768, node_feature_dim)
        self.conv1 = GCNConv(node_feature_dim, hidden_dim)
        self.conv2 = GCNConv(hidden_dim, hidden_dim)
        self.fc = nn.Linear(hidden_dim, output_dim)

    def forward(self, data):
        x, edge_index, edge_attr, batch = data.x, data.edge_index, data.edge_attr, data.batch
        x = self.initial_linear(x)
        x = self.conv1(x, edge_index, edge_weight=edge_attr)
        x = torch.relu(x)
        x = self.conv2(x, edge_index, edge_weight=edge_attr)
        x = torch.relu(x)
        x = global_mean_pool(x, data.batch)  # 图级别的池化
        x = self.fc(x)
        return x


if __name__ == "__main__":
    print(("cuda" if torch.cuda.is_available() else "cpu"))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    N = 1206  #HDFS:48, BGL:1847, THU：1206
    D = 64 #HDFS:16, BGL:64, THU：64
    hidden_dim=64 #HDFS:32, BGL:128, THU：64
    output_dim=2
    learning_rate=0.01#HDFS:0.001, BGL:0.001, THU：0.01
    l2=10e-8

    # # Bert
    bert_path = 'bert-base-uncased'
    bert_tokenizer = BertTokenizer.from_pretrained(bert_path)
    bert_model = BertModel.from_pretrained(bert_path)
    templates_path='FinalData/Thunderbird/RAW/Thunderbird_20M.log_templates.csv'
    sentences=load_data(templates_path)
    encoded_inputs = bert_tokenizer(sentences, padding=True, truncation=True, return_tensors='pt')
    with torch.no_grad():
        output = bert_model(**encoded_inputs)
        last_hidden_state = output.last_hidden_state
    sentence_embeddings = last_hidden_state[:, 0, :]
    node_embedding=sentence_embeddings

    # # data load
    # train_path='./FinalData/HDFS/HDFS_train.csv'
    # test_path='./FinalData/HDFS/HDFS_test.csv'
    # train_weight='./FinalData/HDFS/train_weight.csv'
    # test_weight='./FinalData/HDFS/test_weight.csv'

    # train_path='./FinalData/BGL/train.csv'
    # test_path='./FinalData/BGL/test.csv'
    # train_weight='./FinalData/BGL/train_weight.csv'
    # test_weight='./FinalData/BGL/test_weight.csv'

    train_path= 'FinalData/Thunderbird/train.csv'
    test_path= 'FinalData/Thunderbird/test.csv'
    train_weight='./FinalData/Thunderbird/train_weight.csv'
    test_weight='./FinalData/Thunderbird/test_weight.csv'

    print('get train graphs')
    train_sequences, train_labels = get_train_sequences_data(train_path)
    train_path_weight=get_path_weight(train_weight)
    train_graphs = get_train_graph_data(train_sequences,train_labels,node_embedding,train_path_weight)

    print('get test graphs')
    test_sequences, test_labels = get_train_sequences_data(test_path)
    test_path_weight=get_path_weight(test_weight)
    test_graphs = get_train_graph_data(test_sequences,test_labels,node_embedding,test_path_weight)

    loader = DataLoader(train_graphs, batch_size=2048,shuffle=True)
    print('data loaded')

    #model = GraphTransformerEdge(in_channels=D, hidden_channels=hidden_dim, out_channels=output_dim)
    model = GraphGCN(node_feature_dim=D, hidden_dim=hidden_dim, output_dim=output_dim)

    class_weights = torch.tensor([1.0, 1.0])
    criterion = nn.CrossEntropyLoss(weight=class_weights)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate,weight_decay=l2)

    # 训练过程
    model.train()
    print('start training...')
    for epoch in range(30):
        for batch in loader:
            optimizer.zero_grad()
            output = model(batch)
            loss = criterion(output, batch.y)
            loss.backward()
            optimizer.step()
        print(f'Epoch {epoch + 1}, Loss: {loss.item()}')
        if (epoch+1) % 1 == 0 and epoch>=0:
            evaluate(model, node_embedding, test_graphs, test_labels)
