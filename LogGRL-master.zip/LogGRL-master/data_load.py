import pandas as pd
import torch
import numpy as np
from scipy.sparse import csr_matrix, csc_matrix


def load_data(data_path):
    log_data=pd.read_csv(data_path,engine='c')
    log_templates=list(log_data['EventTemplate'])
    return log_templates

def get_train_data(train_path):
    train_data=pd.read_csv(train_path,engine='c')
    sequences=[]
    sequences_str,labels=list(train_data['Sequence']),list(train_data['label'])
    for seq in sequences_str:
        array = seq.strip().split(' ')
        array=[int(i)-1 for i in array]
        sequences.append(array)
    return sequences,labels


def get_test_data(test_path):
    test_data=pd.read_csv(test_path,engine='c')
    sequences = []
    sequences_str, labels = list(test_data['Sequence']), list(test_data['label'])
    for seq in sequences_str:
        array = seq.strip().split(' ')
        array = [int(i) - 1 for i in array]
        sequences.append(array)
    return sequences, labels

def get_train_graph(sequences):
    graphs=[]#池化后的图结构,
    for sequence in sequences:
        graph=[]#[(node1,node2),(node2,node3),...,(nodei,nodej)]
        for j in range(len(sequence) - 1):
            head,tail=sequence[j], sequence[j + 1]
            if head!=tail:
                # # 此处是保存有向图
                # if (head, tail) not in graph:
                #     graph.append((head, tail))
                # 此处是保存无向图
                if (head, tail) not in graph and (tail, head) not in graph:
                    graph.append((head, tail))
        if len(graph)==0:# 如果序列元素全相同，或者只有一个
            graph.append((sequence[0], sequence[-1]))
        graphs.append(graph)
    return graphs

def get_normal_graph(graphs,shape):
    graph_matrices=[]
    for graph in graphs:
        graph_matrix=np.zeros(shape, dtype=np.float32)
        for tuple in graph:
            x,y=tuple
            graph_matrix[x][y] = 1
            graph_matrix[y][x] = 1
            graph_matrix[y][y] = 1
            graph_matrix[x][x] = 1
        csr=csr_matrix(graph_matrix)#保存为csr_matrix形式，目的是节省内存。
        graph_matrices.append(csr)
    return graph_matrices